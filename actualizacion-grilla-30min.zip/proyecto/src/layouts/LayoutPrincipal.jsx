import { NavLink } from "react-router-dom";
import usarAutenticacion from "../ganchos/usarAutenticacion.js";

const enlaces = {
  ALUMNO: [
    ["/alumno", "Inicio"], ["/alumno/reservas", "Reservas"], ["/alumno/progreso", "Progreso"], ["/alumno/perfil", "Perfil"],
  ],
  PROFESOR: [
    ["/profesor", "Panel"], ["/profesor/calendario", "Calendario"], ["/profesor/alumnos", "Alumnos"], ["/profesor/comisiones", "Comisiones club"],
  ],
  ADMIN: [
    ["/admin", "Panel"], ["/admin/rendiciones", "Rendiciones"], ["/admin/estadisticas", "Estadísticas"], ["/admin/configuracion", "Configuración"],
  ],
};

export default function LayoutPrincipal({ titulo, subtitulo, children }) {
  const { usuario, cerrarSesion } = usarAutenticacion();
  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="marca"><span>LS</span><div><strong>Padel Coach</strong><small>{usuario?.rol}</small></div></div>
        <nav>{enlaces[usuario?.rol]?.map(([to, label]) => <NavLink key={to} to={to}>{label}</NavLink>)}</nav>
        <button className="boton-secundario" onClick={cerrarSesion}>Cerrar sesión</button>
      </aside>
      <main className="contenido">
        <header className="topbar">
          <div><h1>{titulo}</h1><p>{subtitulo}</p></div>
          <div className="usuario-chip"><span className="avatar-mini">{usuario?.nombre?.charAt(0)}</span>{usuario?.nombre}</div>
        </header>
        {children}
      </main>
    </div>
  );
}
