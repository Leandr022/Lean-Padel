import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import LayoutPrincipal from "../../layouts/LayoutPrincipal.jsx";
import TarjetaEstadistica from "../../componentes/ui/TarjetaEstadistica.jsx";
import { estadisticasClub } from "../../servicios/estadisticas.js";

export default function PanelAdmin() {
  const [datos, setDatos] = useState(undefined);

  useEffect(() => {
    estadisticasClub().then(setDatos).catch(() => setDatos(null));
  }, []);

  return (
    <LayoutPrincipal titulo="Panel administrador" subtitulo="Control general del club, horarios y rendiciones.">
      <section className="stats-grid">
        <TarjetaEstadistica titulo="Alumnos activos" valor={datos ? datos.alumnosActivos : "…"} />
        <TarjetaEstadistica titulo="Día más concurrido" valor={datos ? datos.diaMasConcurrido : "…"} />
        <TarjetaEstadistica titulo="Categoría principal" valor={datos ? datos.categoriaPrincipal : "…"} />
        <TarjetaEstadistica titulo="Clases del mes" valor={datos ? datos.clasesDelMes : "…"} />
      </section>
      <section className="dashboard-grid">
        <Link className="dashboard-card verde" to="/admin/rendiciones">Rendiciones</Link>
        <Link className="dashboard-card azul" to="/admin/estadisticas">Estadísticas</Link>
        <Link className="dashboard-card naranja" to="/admin/configuracion">Configuración</Link>
      </section>
    </LayoutPrincipal>
  );
}
