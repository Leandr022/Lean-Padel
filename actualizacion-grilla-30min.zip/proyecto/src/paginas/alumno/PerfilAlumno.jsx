import { useState } from "react";
import LayoutPrincipal from "../../layouts/LayoutPrincipal.jsx";
import usarAutenticacion from "../../ganchos/usarAutenticacion.js";
import { actualizarPerfil, subirFotoPerfil } from "../../servicios/perfiles.js";

const categorias = ["C8", "C7", "C6", "C5", "C4", "C3", "C2", "C1", "D8", "D7", "D6", "D5", "D4", "D3", "D2", "D1"];

export default function PerfilAlumno() {
  const { usuario } = usarAutenticacion();
  const [form, setForm] = useState({
    instagram: usuario.instagram || "",
    telefono: usuario.telefono || "",
    telefono_visible: usuario.telefono_visible,
    categoria: usuario.categoria,
    posicion: usuario.posicion,
    foto_url: usuario.foto_url || "",
  });
  const [guardando, setGuardando] = useState(false);
  const [mensaje, setMensaje] = useState("");
  const [error, setError] = useState("");

  async function subirFoto(e) {
    const archivo = e.target.files?.[0];
    if (!archivo) return;
    try {
      const url = await subirFotoPerfil(usuario.id, archivo);
      setForm((prev) => ({ ...prev, foto_url: url }));
    } catch {
      setError("No se pudo subir la foto.");
    }
  }

  async function guardar() {
    setGuardando(true);
    setError("");
    setMensaje("");
    try {
      await actualizarPerfil(usuario.id, form);
      setMensaje("Cambios guardados. Se van a ver reflejados al recargar la página.");
    } catch {
      setError("No se pudieron guardar los cambios.");
    } finally {
      setGuardando(false);
    }
  }

  return (
    <LayoutPrincipal titulo="Mi perfil" subtitulo="Datos visibles para profesor y alumnos según tu configuración.">
      <section className="form-card">
        <div className="perfil-header">
          <div className="avatar-grande">{usuario.nombre?.charAt(0)}</div>
          <div>
            <h2>{usuario.nombre}</h2>
            <p>{usuario.categoria} · {usuario.genero} · {usuario.posicion}</p>
          </div>
        </div>
        <div className="form-grid">
          <label>
            Foto de perfil
            <input type="file" accept="image/*" onChange={subirFoto} />
          </label>
          <label>
            Instagram
            <input placeholder="@usuario" value={form.instagram} onChange={(e) => setForm({ ...form, instagram: e.target.value })} />
          </label>
          <label>
            Teléfono
            <input value={form.telefono} onChange={(e) => setForm({ ...form, telefono: e.target.value })} />
          </label>
          <label>
            Visibilidad teléfono
            <select
              value={form.telefono_visible ? "visible" : "oculto"}
              onChange={(e) => setForm({ ...form, telefono_visible: e.target.value === "visible" })}
            >
              <option value="visible">Visible</option>
              <option value="oculto">Oculto</option>
            </select>
          </label>
          <label>
            Categoría
            <select value={form.categoria} onChange={(e) => setForm({ ...form, categoria: e.target.value })}>
              {categorias.map((c) => (
                <option key={c}>{c}</option>
              ))}
            </select>
          </label>
          <label>
            Posición
            <select value={form.posicion} onChange={(e) => setForm({ ...form, posicion: e.target.value })}>
              <option>Drive</option>
              <option>Revés</option>
              <option>Indistinto</option>
            </select>
          </label>
        </div>
        {error && <div className="error-box">{error}</div>}
        {mensaje && <div className="panel-resumen">{mensaje}</div>}
        <button className="boton-principal" disabled={guardando} onClick={guardar}>
          {guardando ? "Guardando…" : "Guardar cambios"}
        </button>
      </section>
    </LayoutPrincipal>
  );
}
