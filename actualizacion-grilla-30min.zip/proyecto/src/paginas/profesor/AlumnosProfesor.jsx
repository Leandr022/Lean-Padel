import { useEffect, useState } from "react";
import LayoutPrincipal from "../../layouts/LayoutPrincipal.jsx";
import PlanillaTecnica from "../../componentes/ui/PlanillaTecnica.jsx";
import { listarAlumnos } from "../../servicios/perfiles.js";

export default function AlumnosProfesor() {
  const [alumnos, setAlumnos] = useState([]);
  const [alumno, setAlumno] = useState(null);
  const [cargando, setCargando] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    listarAlumnos()
      .then((datos) => {
        setAlumnos(datos);
        setAlumno(datos[0] || null);
      })
      .catch(() => setError("No se pudo cargar la lista de alumnos."))
      .finally(() => setCargando(false));
  }, []);

  return (
    <LayoutPrincipal titulo="Gestión de alumnos" subtitulo="Entrá al perfil y completá la planilla técnica: se guarda sola.">
      {error && <div className="error-box aviso-pagina">{error}</div>}
      {cargando && <p className="texto-muted">Cargando…</p>}

      {!cargando && alumnos.length === 0 && <p className="texto-muted">Todavía no hay alumnos registrados.</p>}

      {alumno && (
        <div className="dos-columnas">
          <section className="lista-card">
            {alumnos.map((a) => (
              <button className={alumno.id === a.id ? "alumno-item activo" : "alumno-item"} onClick={() => setAlumno(a)} key={a.id}>
                <strong>{a.nombre}</strong>
                <span>{a.categoria} · {a.genero}</span>
              </button>
            ))}
          </section>
          <section className="detalle-card">
            <h2>{alumno.nombre}</h2>
            <p>{alumno.categoria} · {alumno.posicion}</p>
            <p className="texto-muted">{alumno.telefono_visible ? alumno.telefono : "Teléfono oculto"} {alumno.instagram && `· ${alumno.instagram}`}</p>
            <PlanillaTecnica alumnoId={alumno.id} modoProfesor />
          </section>
        </div>
      )}
    </LayoutPrincipal>
  );
}
