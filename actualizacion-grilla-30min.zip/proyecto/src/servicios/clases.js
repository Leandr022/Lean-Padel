import { supabase } from "../lib/supabaseClient.js";

/** Trae las clases entre dos fechas (yyyy-mm-dd) junto con sus reservas y los datos del alumno. */
export async function listarClasesRango(desde, hasta) {
  const { data, error } = await supabase
    .from("clases")
    .select("*, reservas(*, perfiles:alumno_id(id, nombre, categoria, genero))")
    .gte("fecha", desde)
    .lte("fecha", hasta)
    .order("fecha", { ascending: true })
    .order("hora", { ascending: true });
  if (error) throw error;
  return data;
}

export async function crearOActualizarClase({ id, fecha, hora, profesorId, estado, tipo, estadoClase, motivo }) {
  const payload = {
    fecha,
    hora,
    profesor_id: profesorId,
    estado,
    tipo: tipo || null,
    estado_clase: estadoClase || "pendiente",
    motivo: motivo || null,
  };
  if (id) {
    const { data, error } = await supabase.from("clases").update(payload).eq("id", id).select().single();
    if (error) throw error;
    return data;
  }
  const { data, error } = await supabase.from("clases").upsert(payload, { onConflict: "fecha,hora,profesor_id" }).select().single();
  if (error) throw error;
  return data;
}

export async function eliminarClase(id) {
  const { error } = await supabase.from("clases").delete().eq("id", id);
  if (error) throw error;
}

export async function bloquearHorario({ fecha, hora, profesorId, motivo }) {
  return crearOActualizarClase({ fecha, hora, profesorId, estado: "bloqueada", motivo });
}

/** Abre como "disponible" todos los horarios de la semana que todavía no
 * existan como fila en Supabase. No pisa clases ya creadas (reservadas,
 * bloqueadas o editadas). */
export async function generarHorariosSemana({ fechas, horarios, profesorId }) {
  const filas = fechas.flatMap((fecha) =>
    horarios.map((hora) => ({ fecha, hora, profesor_id: profesorId, estado: "disponible", estado_clase: "pendiente" }))
  );
  const { data, error } = await supabase
    .from("clases")
    .upsert(filas, { onConflict: "fecha,hora,profesor_id", ignoreDuplicates: true })
    .select();
  if (error) throw error;
  return data;
}
